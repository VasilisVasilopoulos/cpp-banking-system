#include<iostream>
void showbalance(double balance);
double deposit();
double withdraw(double balance);
int main(){
	double balance =123;
	int choice=0;
	do{
		std::cout<<"enter your choice \n";
		std::cout<<"1. show balance: \n";
		std::cout<<"2. deposit money: \n";
		std::cout<<"3. withdraw money: \n";
		std::cout<<"4. exit \n";
		std::cin>>choice;
	
		switch(choice){
			case 1:
				showbalance(balance);
				break;
			case 2:
				balance += deposit();
				showbalance(balance);
				break;
			case 3:
				balance -=withdraw(balance);
				showbalance(balance);
				break;
			case 4:
				std::cout<<"thanks for visitting\n";
				break;
		
		}
		
	}while(choice!=4);	

}
void showbalance(double balance){
	std::cout<<"your balance is: "<<balance<<'\n';
}
double deposit(){
	double amount=0;
	std::cout<<"how much you want to deposit: ";
	std::cin>>amount;
	if(amount>0){
		return amount;
	}
	else{
		std::cout<<"not valid";
		return 0;
	}
}

double withdraw(double balance){
	double amount=0;
	std::cout<<"how much you getting out ";
	std::cin>>amount;
	if(amount>balance){
		std::cout<<"you dont have that much money";
		return 0;
	}
	return amount;
}

